function [R_jf, tl_jf] = JF_fwd(x,t0,D_aam,D_tlm)
%Amplitude ratio and time lag calculation for Jacob-Ferris
R_jf = exp(-x .* sqrt(pi./(t0.*D_aam)));
tl_jf = x.*sqrt(t0./(4*pi().*D_tlm));
end
