function [D_aam, D_tlm] = JF_model(x,R,tl,t0)
%Diffusivity estimation from amplitude attenuation and time lag method of Jacob-Ferris
D_aam = (x./log(R)).^2 .* (pi()./t0);
D_tlm = (x./tl).^2.*t0/(4*pi());
end



