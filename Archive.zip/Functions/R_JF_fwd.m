function R_jf = R_JF_fwd(x,t0,D)
%Diffusivity estimation from amplitude attenuation method of Jacob-Ferris
R_jf = exp(-x .* sqrt(pi./(t0.*D)))
end
