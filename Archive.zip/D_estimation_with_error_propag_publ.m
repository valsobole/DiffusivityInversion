% Author:   Valeriia Soboelvskaia
% email:    valeriia.soboelvskaia@gmail.com
% May 2020; Last revision: 3-Dec-2020
clear all; clc; close all;
set(groot,'defaulttextinterpreter','latex');
set(groot, 'defaultAxesTickLabelInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
lbl_sz = 23;
ax_sz = 16;
set(0,'defaultAxesFontSize',ax_sz)

%% -------------- Data Loading --------------------------------------------
% -> Make sure your working directory is the same as the code .m file location
mypath = cd;
addpath('Functions')
cd Data
pname = cd;
cd ..

warning('off','MATLAB:table:ModifiedAndSavedVarnames');                     % Turn off some warnings
warning('off','MATLAB:MKDIR:DirectoryExists');

fname1 = 'Head_data.csv';                                                   % Your input head data file. Second file 'Head_data2.csv'
data = csvread(strcat(pname,'/',fname1), 1, 1);
time_h = data(1:end-1,1);                                                   % time in hours
time_all = linspace(0,time_h(end),length(time_h))'.*3600;                   % time in sec
fname2 = 'Distance_pairs.csv';                                              % Your distance between the wells
DataPairs = readtable(strcat(pname,'/',fname2));
DataPairs = table2array(DataPairs);

%% -------------- Select data ---------------------------------------------
% -> To select working wells, use the list below to chose n (river) and k(well)
well = ["Meghna Stairs";    % 2
    "Veast T6";         % 3
    "Veast T5";         % 4
    "Veast T3";         % 5-no data
    "Veast T1";         % 6
    "Veast 2";          % 7-no data
    "Veast 1b";         % 8-no data
    "Veast 1a"];        % 9

n = 2;                      % river can be # 2, 3 or 4 (3 is in the second file)
k = 9;                      % well can be # 3 to 9 (3 is in the second file)
river = well{n-1};            head_river_all = data(1:end-1,str2double(DataPairs{n,5}));
well = well{k-1};             head_well_all = data(1:end-1,str2double(DataPairs{k,5}));
distance = str2double(DataPairs{k,n});                                      % distance from the shore (m)

% Plotting original data
head_river_all(head_river_all==0)=nan;
head_well_all(head_well_all==0)=nan;
t1 = datetime(2015,4,19,00,00,0);                                           % time veactor in date format ; 2013,6,21,18,20,0  for second file
t2 = datetime(2016,1,10,14,00,0);                                           % 2015,6,10,14,40,0 for second file
t = (t1:minutes(20):t2)';
%---------------- Figure 1 - Display original data ------------------------
fig_original_data = figure(1);
set(fig_original_data, 'Position', [100 200 1200 500]);
%----------------
plot(t, head_river_all,'-b','LineWidth',1); hold on;
plot(t, head_well_all,'-r','LineWidth',1);
xlabel('Date','FontSize', lbl_sz)
ylabel('Hydraulic head (m)','FontSize', lbl_sz)
set(gca, 'XMinorTick', 'on')
l1 = legend(river,well,'Location','Northeast','orientation','vertical'); legend boxoff
set(l1, 'FontSize',lbl_sz);
xlim([t(1) t(end)]);
ylim([0 8]);
t1 = dateshift(t1, 'start', 'month','next');   t2 = dateshift(t2, 'start', 'month');
ticlocs = t1:calmonths(3):t2;
ticlocs.Format = 'MMM-yyyy';
set(gca, 'XTick', ticlocs);
%-----------------
% Printing and saving the figure
path = (sprintf('%s/Figures/%s_%s/',mypath,river,well));
mkdir (sprintf('%s/Figures/%s_%s/',mypath,river,well));
fig_original_data.PaperPositionMode = 'auto';
print('original_data','-depsc','-r0')
movefile('original_data.eps',path);

%% -------------- Limiting the original data to the time of interest-------
% -> By default the code uses all data avialbe. If the results are noisy,
% you will get a Warning: "Invalid values. QC results". In this case, use
% Fig. 5-6 to identify the noisy interval and remove it from analysis by
% commenting line (82) and uncomentitng line (83). Run the code again and
% you will be prompted to select a working interavl from Fig. 1.

%time_int = [time_all(1); time_all(end)];                                    % all data used by default
[time_int, head_int]=ginput(2);                                             % choose the start and the end of the interval interactively

ind = time_all>(time_int(1)*3600*24) & ...
    time_all<(time_int(2)*3600*24) & head_river_all>0 & head_well_all>0;    % find the indeces of the beginning and end values in the original array
time = time_all(ind);                                                       % limit the original time array to the times of interest
head_river = head_river_all(ind);
head_well = head_well_all(ind);
time = time - time(1);                                                      % reset time array to start with zero
head_river = head_river - mean(head_river);                                 % remove the average river head from the head data
head_well = head_well - mean(head_well);

%---------------- Figure 2 - Time of interest -----------------------------
fig_limited_data = figure(2);
set(fig_limited_data, 'Position', [100 200 1200 500]);
%----------------
plot(time/(3600*24), head_river,'-b','LineWidth',1); hold on;
plot(time/(3600*24), head_well,'-r','LineWidth',1);

xlabel('Time (days)','FontSize',lbl_sz);
ylabel('Mean hydraulic head (m)','FontSize',lbl_sz);
l1 = legend(river, well,'Location','Northeast','orientation','vertical'); legend boxoff
set(l1, 'FontSize',lbl_sz);
set(gca, 'XMinorTick', 'on');
%----------------
% Printing and saving the figure
fig_limited_data.PaperPositionMode = 'auto';
print('limited_data','-depsc','-r0')
movefile('limited_data.eps',path);

%% -------------- Main FFT calculations and data conditioning -------------
% -> The parameters below are adapted for the provided dataset. Please
% modify accoedingly for your dataset cut off frequencies at lines (144-
% 145), and autopicking intervals p at line (150) and parameters NPks
% (number fo peaks) and MPD (min peak distance) at line (151). Use other
% controlling parameters if needed.
%**************************** FFT Calculation *****************************
dt = time(2)-time(1);
Fs = 1/dt;
N = size(data,1);
nfft = N;
K = round(nfft/2);

w = Fs/2*linspace(0,1,K);                                                   % frequency array in Hz
period = (1./w)/(3600*24);                                                  % period in days
% Fourier decomposition for River
amp_head_river = abs(fft(head_river,nfft)/N);                               % FFT ampmlitude spectrum
amp_fft_corrected_river = amp_head_river(1:K).*2;

% Fourier decomposition for Well
amp_head_well = abs(fft(head_well,nfft)/N);                                 % FFT ampmlitude spectrum
amp_fft_corrected_well = amp_head_well(1:K).*2;

% Phase shift between head data -- cross-power spectral density method
[P_data, f] = cpsd(head_river,head_well,[],0,nfft,Fs);
phase_data = rad2deg(angle(P_data));
phase_data = phase_data(1:length(period));

% Filter out arrays for values between discrete low and high frequency limit
p1 = 0.15;                                                                  % low cut-off frequency, should be modified for a different dataset
p2 = 1.5;                                                                   % high cut-off frequency, should be modified for a different dataset
idx = period>p1 & period<p2;
periods_main = period(idx);

% Find peaks within defined intervals
p = [10/24 13/24; 5/24 7/24; 21/24 27/24];                                  % Added to make sure that we pick the same peaks in different pairs
NPks = [2 1 2];                 MPD = [5 5 8];                              % Parameters for auto-picking. Adjust accordingly
amps_river_peaks = [];
[amps_well_peaks, periods, phase_lag_peaks] = deal(zeros(sum(NPks),1));

for i=1:numel(NPks)
    idx = period>p(i,1) & period<p(i,2);
    periods_temp = period(idx);
    amps_river_temp = amp_fft_corrected_river(idx);
    amps_well_temp = amp_fft_corrected_well(idx);
    phase_data_temp = phase_data(idx);
    
    K = numel(amps_river_peaks)+1;
    [amps_river_peaks(K:K+NPks(i)-1), locs] = findpeaks(amps_river_temp,...
        'SortStr','descend','NPeaks',NPks(i),'MinPeakDistance', MPD(i));
    periods(K:K+NPks(i)-1) = periods_temp(locs)';
    amps_well_peaks(K:K+NPks(i)-1) = amps_well_temp(locs);
    phase_lag_peaks(K:K+NPks(i)-1) = phase_data_temp(locs);
    clear periods_temp amps_river_temp amps_well_temp phase_data_temp
end
periods_all = periods;
R_all = amps_well_peaks ./ amps_river_peaks';
tL_all = phase_lag_peaks .* periods ./360;

%---------------- Figure 3 - Amplitude spectrum ---------------------------
limx = [0.6*p1 1.2*p2];
xlbl = [0.1 0.5 1];
fig_FFT_amp = figure(3);
set(fig_FFT_amp, 'Position', [100 200 1200 650]);
%----------------
stem(period, amp_fft_corrected_river,'-bo','LineWidth',1,...
    'markerfacecolor','b','markersize',5); hold on;
stem(period, amp_fft_corrected_well,'-ro','LineWidth',1,...
    'markerfacecolor','r','markersize',5);

plot(periods, amps_river_peaks, 'kv','markerfacecolor','k','markersize',14);
for i=1:5
    text(periods(i)-0.01, amps_river_peaks(i)+0.03*max(amps_river_peaks),...
        sprintf('$t_{%1.0f}$ = %.1f hours',i,periods(i)*24),...
        'Interpreter','latex','FontSize', .7*lbl_sz,...
        'FontName', 'courier', 'FontWeight','bold');
end
set(gca, 'XMinorTick', 'on','xscal','log');
xlabel('Period (days)','FontSize', lbl_sz,'FontWeight','bold');
ylabel('Fourier Power Spectrum','FontSize', lbl_sz,'FontWeight','bold');
l1 = legend(river, well,'Location','Northeast','orientation','vertical');
legend boxoff; grid on;
set(l1, 'FontSize',lbl_sz);
xlim(limx); xticks(xlbl);
ylim([10^(-4) 1.2*max(amps_river_peaks)]);
%----------------
% printing and saving the figure
name = (sprintf('FFT_amp_%s_%s.eps',river,well));
fig_FFT_amp.PaperPositionMode = 'auto';
print(name,'-depsc','-r0')
movefile(name,path);
%-----------------------Figure 4 - Phase spectrum--------------------------
fig_FFT_ph_spectrum = figure(4);
set(gcf,'renderer','Painters')
set(fig_FFT_ph_spectrum, 'Position', [100 200 600 450]);
%----------------
stem(period, phase_data,'-bo','LineWidth',1,...
    'markerfacecolor','b','markersize',5); hold on;
stem(period, phase_data,'-ro','LineWidth',1,...
    'markerfacecolor','r','markersize',5);
plot(periods, phase_lag_peaks, 'kv','markerfacecolor','k','markersize',10);
set(gca, 'XMinorTick', 'on','xscal','log');
xlabel('Period (days)','FontSize', lbl_sz,'FontWeight','bold');
ylabel('Fourier Phase Spectrum (deg)','FontSize', lbl_sz,'FontWeight','bold');
xlim(limx); xticks(xlbl);
ylim([0 180]);
%l1 = legend(river,well, 'Peaks','Location','Northeast','orientation','vertical');
%legend boxoff;
%set(l1, 'FontSize',25, 'Interpreter','latex');
grid on
%----------------
%printing and saving the figure
name = (sprintf('fig_FFT_ph_spectrum_%s_%s.eps',river,well));
fig_FFT_ph_spectrum.PaperPositionMode = 'auto';
print(name,'-depsc','-r0')
movefile(name,path);

%% -------------- Sliding window FFT calculations and data conditioning ---
% -> Adjust parameters as necessary. Current parameters adapted for our
% dataset. Lines (247) - windows length is days, (259) - windwos step,
% (267-269) same as above or adjust if data is noisy. If you get warnings,
% adjust input data interval back on line (82).

%**************************** FFT Calculation *****************************
dt = round(time(2)-time(1));                                                % sampling in seconds
Fs = 1/dt;                                                                  % data sampling frequency
window_days = 100;                                                           % !!! Has to be ajusted based on sensitivity analysis
coeff = round(window_days * 24 * 3600 /(2 * dt));
window = 2 * coeff * dt;                                                    % window in seconds
N = size(data,1);

nfft = 2.^(nextpow2(window/dt));                                            % number of samples in the window for further FFT, should be a power of two
w = Fs/2*linspace(0,1,nfft/2+1);                                            % frequency array in Hz
period = (1 ./ w) / (3600 * 24);                                            % period in days

% defining the beginning and the end of the gated time-array
z1 = ((window/2)/dt) + 1;                                                   % first index in time that fits 1/2 window before
z2 = numel(time) - (window/2)/dt;                                           % last index in time that fits 1/2 window after
step = 25;                                                                   % !!! Has to be ajusted based on sensitivity analysis
coeff2 = round((z2-z1)/step);
step_true = (z2-z1)/coeff2;
z_array = z1:step_true:z2;                                                  % create a time-array for time-sliding windows
time_array = linspace(window_days/2, ...
    (time(end)/(24*3600)) - window_days/2, length(z_array));                % time-array, corresponding to the sliding-window array

% Find peaks within defined intervals
p = [5/24 7/24; 10/24 13/24; 22/24 28/24];                                 % period intervals to find well-defined peaks
NPks = [1 2 2];                                                            % number of peaks to find in each period interval
MPD = [4 4 4];                                                              % minimum peak distances
amps_river_peaks = zeros(numel(z_array), sum(NPks));
[amps_well_peaks, periods, phase_lag_peaks] = deal(zeros(1, sum(NPks)));

tic;
try
    % ------------------- start a waitbar --------------------------------
    h = waitbar(2,'1','Name','Iterating through time, computing amplitude ratios and phases',...
        'CreateCancelBtn',...
        'setappdata(gcbf,''canceling'',1)');
    set(h, 'Position', [100 200 450 100]);
    setappdata(h,'canceling',0)
    % --------------------------------------------------------------------
    for z = 1:length(z_array)
        % ------------ Check for Cancel button press ---------------------
        if getappdata(h,'canceling')
            break
        end
        waitbar(z_array(z)/(z_array(end)), h, sprintf('%.1f percent done', ...
            round(z_array(z)*100/(z_array(end)),1)));
        % -----------------------------------------------------------------
        
        head_river_wind = head_river(round((z_array(z) - window/2/dt)) ...
            : round((z_array(z) + window/2/dt)));                           % windowed upstream signal
        head_well_wind = head_well(round((z_array(z) - window/2/dt)) ...
            : round((z_array(z) + window/2/dt)));                           % windowed downstream signa
        
        % Fourier decomposition for Meghna stairs - we want to save the
        % whole matrix for further demonstration
        amp_head_river = abs(fft(head_river_wind,nfft)/N);
        amp_fft_corrected_river = amp_head_river(1:nfft/2+1).*2;
        
        % Fourier decomposition for well
        amp_head_well = abs(fft(head_well_wind,nfft)/N);
        amp_fft_corrected_well = amp_head_well(1:nfft/2+1).*2;
        
        % phase shift between head data -- Welch's cross-power spectral
        % density method
        [P_data, f] = cpsd(head_river_wind,head_well_wind,[],0,nfft,Fs);
        phase_data = rad2deg(angle(P_data));
        K=1;
        
        for i=1:numel(NPks)
            idx = period>p(i,1) & period<p(i,2);
            periods_temp = period(idx);
            amps_river_temp = amp_fft_corrected_river(idx);
            amps_well_temp = amp_fft_corrected_well(idx);
            phase_data_temp = phase_data(idx);
            
            [amps_river_peaks(z,K:K+NPks(i)-1), locs] = findpeaks(amps_river_temp,...
                'SortStr','descend','NPeaks',NPks(i),'MinPeakDistance', MPD(i));
            periods(z,K:K+NPks(i)-1) = periods_temp(locs)';
            amps_well_peaks(z, K:K+NPks(i)-1) = amps_well_temp(locs);
            phase_lag_peaks(z, K:K+NPks(i)-1) = phase_data_temp(locs);
            clear periods_temp amps_river_temp amps_well_temp phase_data_temp
            K=K+NPks(i);
        end
        
    end
    toc;
    
catch ME
    delete(h);
    rethrow(ME) %re-issue the error
end
delete(h);
%----------------
% Accumulate data into arrays
R = amps_well_peaks ./ amps_river_peaks;
time_lag = phase_lag_peaks .* periods ./360;

% Check if data is noisy
R(R>=1) = NaN;              time_lag(time_lag<=0) = NaN;
if sum(sum(isnan(R)))>0 || sum(sum(isnan(time_lag)))>0
    warning('Invalid values. QC results and/or adjust input data interval (line 79)')
end

%% -------------- Calculate key statistics and display --------------------

period_mean = (nanmean(periods) .* 24)';                                    % mean periods for each peak, in hours
periods_std = (nanstd(periods) .* 24)';                                   	% STD periods for each peak, in hours
R_mean = (nanmean(R))';                                                   	% mean R for each peak
R_std = (nanstd(R))';                                                    	% STD R for each peak
tL_mean = (nanmean(time_lag))';                                           	% mean time lag for each peak, in days
tL_std = (nanstd(time_lag))';                                               % STD time lag for each peak, in days

%---------------- Figure 5 - subplot of R as a function of time -----------
fig_R_vs_time = figure(5);
set(fig_R_vs_time, 'Position', [100 200 750 900]);
[~, idx] = sort(period_mean);

for i=1:length(R_mean)
    subplot(5,1,i)
    plot(time_array, R(:,idx(i)), '-k','LineWidth',1);
    set(gca,'XMinorTick','on');
    ylim([0 1]); xlim([min(time_array) max(time_array)]);
    if i<length(R_mean)
        xlabel(" ")
    else
        xlabel("Sliding window ime (days)",'FontSize', lbl_sz)
    end
    if i~=round(length(R_mean)/2)
        ylabel(" ")
    else
        ylabel("Amplitude ratio (unitless)",'FontSize', lbl_sz)
    end
    title(sprintf('T = %.1f hours ~~~ $R_{mean}$ = %.2f ~~~ $\\sigma_{R}$ = %.3f',...
        period_mean(idx(i)), R_mean(idx(i)), R_std(idx(i))),...
        'FontSize', .7*lbl_sz,'FontWeight','bold');
end
%----------------
% printing and saving the figure
name = (sprintf('R_vs_time_%s_%s.eps',river,well));
fig_R_vs_time.PaperPositionMode = 'auto';
print(name,'-depsc','-r0');
movefile(name,path);

%----------- Figure 6 - subplot of time lag as a function of time ---------
fig_theta_vs_time = figure(6);
set(fig_theta_vs_time, 'Position', [100 200 750 900]);
[~, idx] = sort(period_mean);

for i=1:length(R_mean)
    subplot(5,1,i)
    plot(time_array, time_lag(:,idx(i)), '-k','LineWidth',1);
    set(gca, 'XMinorTick','on');
    ylim([0 0.1]); xlim([min(time_array) max(time_array)]);
    if i<length(R_mean)
        xlabel(" ")
    else
        xlabel("Sliding window time (days)",'FontSize', lbl_sz)
    end
    if i~=round(length(R_mean)/2)
        ylabel(" ")
    else
        ylabel("Time lag (days)",'FontSize', lbl_sz)
    end
    title(sprintf('T = %.1f hours ~~~ $R_{mean}$ = %.2f ~~~ $\\sigma_{R}$ = %.3f',...
        period_mean(idx(i)), R_mean(idx(i)), R_std(idx(i))),...
        'FontSize', .7*lbl_sz, 'FontWeight','bold');
end
%----------------
% printing and saving the figure
name = (sprintf('theta_vs_time_%s_%s.eps',river,well));
fig_theta_vs_time.PaperPositionMode = 'auto';
fig_pos = fig_theta_vs_time.PaperPosition;
fig_theta_vs_time.PaperSize = [fig_pos(3) fig_pos(4)];
print(name,'-depsc','-r0');
movefile(name,path);

%%
%----------- Figure 7 - R and tL histograms -------------------------------
fig_histograms = figure(7);
set(fig_histograms, 'Position', [10 1000 1400 500]);
[~, idx] = sort(period_mean);
N = length(period_mean);
%Top row - R
for i=1:N
    subplot(2,5,i)
    pd = fitdist(R(:,idx(i)),'normal');
    h = histfit(R(:,idx(i)),max(round(150*pd.sigma),3));
    h(1).FaceColor = [0.75 0.75 0.75];
    h(2).Color = 'k';
    xlim([0 1]);
    ylim([0 1.4*max(h(1).YData)]);
    mygca(i) = gca;
    set(gca,'XMinorTick','on');
    title(sprintf('T = %.1f hours',period_mean(idx(i))),'FontSize',.7*lbl_sz);
    if i~=round(N/2)
        xlabel(" ")
    else
        xlabel({'Amplitude ratio (unitless)',''},'FontSize',lbl_sz)
    end
    %------ annotations -------------
    annotation(fig_histograms,'textbox', get(subplot(2,5,i),'position'),...
        'String',{sprintf('$R_{mean}$ = %.3f \n $\\sigma_{R}$ = %.4f',...
        pd.mu, pd.sigma)}, 'LineStyle','none', 'Interpreter','latex',...
        'FontSize',.7*ax_sz, 'FitBoxToText','off');
end
xl = cell2mat(get(mygca, 'Xlim'));
xlnew = [min(xl(:,1)) max(xl(:,2))];
xtnew = linspace(xlnew(1),xlnew(2),3);
set(mygca, 'Xlim', xlnew, 'XTick', xtnew)
%Bottom row - tL
for i=N+1:2*N
    subplot(2,5,i)
    pd = fitdist(time_lag(:,idx(i-N)),'normal');
    h = histfit(time_lag(:,idx(i-N)),max(round(2000*pd.sigma),3));
    h(1).FaceColor = [0.9 0.9 0.9];
    h(2).Color = 'k';
    xlim([0 0.1]);
    mygca(i-N) = gca;
    ylim([0 1.4*max(h(1).YData)]);
    set(gca,'XMinorTick','on');
    title(sprintf('T = %.1f hours',period_mean(idx(i-N))),'FontSize', .7*lbl_sz);
    if i~=N+round(N/2)
        xlabel(" ")
    else
        xlabel("Time lag (days)",'FontSize', lbl_sz)
    end
    %------ annotations -------------
    annotation(fig_histograms,'textbox', get(subplot(2,5,i),'position'),...
        'String',{sprintf('$t_{L,mean}$ = %.3f \n $\\sigma_{t_{L}}$ = %.4f',...
        pd.mu, pd.sigma)}, 'LineStyle','none', 'Interpreter','latex',...
        'FontSize',.7*ax_sz, 'FitBoxToText','off');
end
xl = cell2mat(get(mygca, 'Xlim'));
xlnew = [round(min(xl(:,1)),1) round(max(xl(:,2)),1)];
xtnew = linspace(xlnew(1),xlnew(2),3);
set(mygca, 'Xlim', xlnew, 'XTick', xtnew)
%----------------
% printing and saving the figure
name = (sprintf('histograms_%s_%s.eps',river,well));
fig_histograms.PaperPositionMode = 'auto';
fig_pos = fig_histograms.PaperPosition;
fig_histograms.PaperSize = [fig_pos(3) fig_pos(4)];
print(name,'-depsc','-r0');
movefile(name,path);

%% -------------- Diffusivity calculation ---------------------------------

[D_aam, D_tlm] = JF_model(distance,R_all,tL_all,periods_all);
[D_aam1, D_tlm1] = JF_model(distance,R_all+R_std,tL_all+tL_std,periods_all); %for error bars plot
[D_aam2, D_tlm2] = JF_model(distance,R_all-R_std,tL_all-tL_std,periods_all); %for error bars plot
% Error propagation
unc_Damp = @(sigma_R,R,t0,x) (2.*pi().*x.^2.*sigma_R)./(t0.*R.*(-log(R)).^3);
sigma_Damp = unc_Damp(R_std,R_mean,periods_all,distance);
unc_DtL = @(sigma_tL,tL,t0,x) (x.^2.*t0.*sigma_tL)./(2*pi().*(tL).^3);
sigma_DtL = unc_DtL(tL_std,tL_mean,periods_all,distance);
%--------------------------------------------------------------------------
% Running joint nonlinear regression for diffusivity (D) and displaying
% results models
mdl1 = @(diff,x) exp(-distance .* sqrt(pi ./ (x .* diff)));                 % amplitude ratio as a function of wave period
mdl2 = @(diff,x) distance .* sqrt(x ./ (4*pi() .* diff));                   % time lag as a function of wave period

% Prepare input for NLINMULTIFIT and perform fitting
diff0 = 1e5;                                                                % initial guess for diffusivity
Rm = mean(R_all);              tLm = mean(tL_all);                          % for weights
[diff_amp,r_amp,J_a,s_amp,~,~] = nlinmultifit({periods_all}, {R_all}, {mdl1}, ...
    diff0, 'Weights', {(Rm./R_std).^2});
[diff_phase,r_phase,J_t,s_phase,~,~,~] = nlinmultifit({periods_all}, {tL_all}, {mdl2}, ...
    diff0, 'Weights', {(tLm./tL_std.^2)});
[diff_joint,r_joint,J_j,s_joint,~,~,~] = nlinmultifit({periods_all,periods_all}, ...
    {R_all,tL_all}, {mdl1, mdl2}, diff0, 'Weights', {(Rm./R_std.^2) (tLm./tL_std.^2)});

t0 = logspace(-1,1,100);                                                    % dummy array of periods (days)
[R_calc_amp, tl_calc_amp] =  JF_fwd(distance,t0, diff_amp, diff_amp);
[R_calc_phase, tl_calc_phase] =  JF_fwd(distance,t0, diff_phase, diff_phase);
[R_calc_joint, tl_calc_joint] =  JF_fwd(distance,t0, diff_joint, diff_joint);

%---------------- Figure 8 - Display main results -------------------------
fig_results = figure(8);
set(fig_results, 'Position', [100 200 900 750]);
xl = [0.1 2];
%----------------
subplot(2,2,1)
semilogx(t0, R_calc_joint,'-','linewidth',1,'Color','k'); hold on;
semilogx(t0, R_calc_amp,'--','linewidth',2,'Color','b');
semilogx(t0, R_calc_phase,'--','linewidth',2,'Color','r');
errorbar(periods_all, R_all, R_std, 'ks', 'MarkerFaceColor','g','markersize', 10);
set(gca, 'XMinorTick', 'on','xscal','log');
xlabel('Period (days)','FontSize', lbl_sz);
ylabel('Amplitude Ratio (unitless)','FontSize', lbl_sz);
l1 = legend('$R_\mathrm{fit}$ using $D_{joint}$', ...
    '$R_\mathrm{fit}$ using $D_{amp}$','$R_\mathrm{fit}$ using $D_{t_L}$','data',...
    'Location','Northwest','orientation','vertical');
set(l1, 'FontSize',.6*lbl_sz);  legend boxoff;
xlim(xl); New_XTickLabel = get(gca,'xtick'); set(gca,'XTickLabel',New_XTickLabel);
%ylim([.4 .9])
%------ annotations -------------
pos_pl = get(subplot(2,2,1),'position');
an = annotation(fig_results,'textbox',pos_pl,'String',...
    {sprintf('${D}_{amp}$ = %.2e ${m}^2/day$ \n${D}_{joint}$ = %.2e ${m}^2/day$',...
    diff_amp, diff_joint)}, 'LineStyle','none','Interpreter','latex',...
    'FitBoxToText','on','FontSize',.6*lbl_sz);
% adjust location
fig_results.PaperPositionMode = 'auto';
name = (sprintf('results_%s_%s.eps',river,well));
print(name,'-depsc','-r0');
pos_an = get(an,'position');
pos_new = [pos_an(1)+pos_pl(3)-pos_an(3) pos_an(2)-pos_pl(4)+pos_an(4) pos_an(3) pos_an(4)];
set(an,'position', pos_new);
%--------------------------------------------------------------------------
subplot(2,2,2)
semilogx(t0, tl_calc_joint,'-','linewidth',1,'Color','k'); hold on;
semilogx(t0, tl_calc_amp,'--','linewidth',2,'Color','b');
semilogx(t0, tl_calc_phase,'--','linewidth',2,'Color','r');
errorbar(periods_all, tL_all, tL_std, 'ko', 'MarkerFaceColor','g','markersize', 10);
set(gca, 'XMinorTick', 'on','xscal','log');
xlabel('Period (days)','FontSize', lbl_sz);
ylabel('Time Lag (days)','FontSize', lbl_sz);
l1 = legend('$t_\mathrm{L,fit}$ using $D_{joint}$', ...
    '$t_\mathrm{L,fit}$ using $D_{amp}$','$t_\mathrm{L,fit}$ using $D_{t_L}$','data',...
    'Location','Northwest','orientation','vertical');
set(l1, 'FontSize',.6*lbl_sz);  legend boxoff;
xlim(xl); New_XTickLabel = get(gca,'xtick'); set(gca,'XTickLabel',New_XTickLabel);
%ylim([.01 .07])
%------ annotations -------------
pos_pl = get(subplot(2,2,2),'position');
an = annotation(fig_results,'textbox',pos_pl,'String',...
    {sprintf('${D}_{t_L}$ = %.2e ${m}^2/day$ \n${D}_{joint}$ = %.2e ${m}^2/day$',...
    diff_phase, diff_joint)}, 'LineStyle','none','Interpreter','latex',...
    'FitBoxToText','on','FontSize',.6*lbl_sz);
% adjust location
fig_results.PaperPositionMode = 'auto';
print(name,'-depsc','-r0');
pos_an = get(an,'position');
pos_new = [pos_an(1)+pos_pl(3)-pos_an(3) pos_an(2)-pos_pl(4)+pos_an(4) pos_an(3) pos_an(4)];
set(an,'position', pos_new);
%--------------------------------------------------------------------------
subplot(2,2,[3 4])
errorbar(periods_all, D_aam, sigma_Damp, 'bs', 'MarkerFaceColor','b','markersize', 10); hold on;
errorbar(periods_all, D_tlm, sigma_DtL, 'ro', 'MarkerFaceColor','r','markersize', 10);
set(gca, 'XMinorTick', 'on','xscal','log');
xlabel('Period (days)','FontSize', lbl_sz);
ylabel('Diffusivity (m$^2$/day)','FontSize', lbl_sz);
l1 = legend('$D_{amp}$', '$D_{t_L}$','Location','Northwest','orientation','vertical');
set(l1, 'FontSize',.7*lbl_sz);
legend boxoff;  xlim(xl);    ylim([0 1.05*max(max([D_aam2 D_tlm2]))]);
New_XTickLabel = get(gca,'xtick'); set(gca,'XTickLabel',New_XTickLabel);
%ylim ([0 3.5e5])
%----------------
% printing and saving the figure
fig_results.PaperPositionMode = 'auto';
print(name,'-depsc','-r0');
movefile(name,path);

%% Save results to .csv
%-----separately by well------
data_final = table(periods_all, R_all, R_std, tL_all, tL_std, D_aam, D_tlm);
data_final.Properties.VariableUnits = {'d','unitless','unitless','d','d','m2/d','m2/d'};
fpname = (sprintf('%s/Figures/%s_%s/uncertainty_results.csv',mypath,river,well));
writetable(data_final,fpname);

data_final = table(diff_amp, diff_phase, diff_joint);
data_final.Properties.VariableUnits = {'m2/d','m2/d','m2/d'};
fpname = (sprintf('%s/Figures/%s_%s/results.csv',mypath,river,well));
writetable(data_final,fpname);

%% Clear working space
clear ind head_river_all head_well_all t1 t2 l1 coeff coeff2 z1 z2 z ...
    amp_head_river amp_head_well ticlocs l1 limx xlbl fig_pos h idx mygca ...
    pd hxl1 xl2 xl3 xl xlnew xtnewN fig_pos an pos_an pos_new xl i k K locs...
    Rm step_true time_all time_h time_int window xtnew w n N
%% ------------------------------------------------------------------------
% Error propagation
rng('default')
s = rng;

numberSamples = 1e3;
R_dist = zeros(numberSamples,5);
tl_dist = zeros(numberSamples,5);
diff_amp_stat = zeros(numberSamples,1);
diff_phase_stat = zeros(numberSamples,1);
diff_joint_stat = zeros(numberSamples,1);

for i = 1:numberSamples
    for j = 1:5
        R_dist(i,j) = normrnd(R_all(j), R_std(j));
        tl_dist(i,j) = normrnd(tL_all(j), tL_std(j));
    end
    [diff_amp_stat(i),~,~,~,~,~,~] = ...
        nlinmultifit({periods_all}, {R_dist(i,:)}, {mdl1}, diff0);
    [diff_phase_stat(i),~,~,~,~,~,~] = ...
        nlinmultifit({periods_all}, {tl_dist(i,:)}, {mdl2}, diff0);
    [diff_joint_stat(i),~,~,~,~,~,~] = ...
        nlinmultifit({periods_all,periods_all}, {R_dist(i,:),tl_dist(i,:)}, {mdl1, mdl2}, diff0);
end

Damp_stats = fitdist(diff_amp_stat,'normal');
Dphase_stats = fitdist(diff_phase_stat,'normal');
Djoint_stats = fitdist(diff_joint_stat,'normal');

disp(strcat('uncertainty in Damp =', num2str(Damp_stats.sigma )));
disp(strcat('uncertainty in Dphase =', num2str(Dphase_stats.sigma)));
disp(strcat('uncertainty in Djoint =', num2str(Djoint_stats.sigma)));
%% ---------------- Figure 9 - Display samples drawn for error propagation --
fig_results = figure(9);
set(fig_results, 'Position', [100 100 1400 450]);
for i = 1:5
    sp(i) = subplot(2,5,i);
    h1 = histfit(R_dist(:,i),25);
    h1(1).FaceColor = [0.75 0.75 0.75];
    h1(2).Color = 'k';
    xlim([0.35 1]); ylim([0 .2*numberSamples]);
    set(gca,'XMinorTick','on');
    title(sprintf('$t_0$ = %.1f hours',periods_all(i)*24),'FontSize', .7*lbl_sz);
    
    annotation(fig_results,'textbox','Position',sp(i).Position,...
        'HorizontalALignment','right',...
        'String',{sprintf('$R_{mean}$ = %.3f \n $\\sigma_{R}$ = %.3f',...
        R_all(i), R_std(i))},'LineStyle','none','Interpreter','latex',...
        'FontSize',.7*ax_sz,'FitBoxToText','on');
end
xlabel(sp(3),'Amplitude Ratio','FontSize', lbl_sz);

for i = 1:5
    sp(i)=subplot(2,5,5+i);
    h1 = histfit(tl_dist(:,i),25);
    h1(1).FaceColor = [0.9 0.9 0.9];
    h1(2).Color = 'k';
    xlim([0.02 0.06]); ylim([0 .2*numberSamples]);
    set(gca,'XMinorTick','on');
    
    annotation(fig_results,'textbox','Position',sp(i).Position,...
        'HorizontalALignment','right',...
        'String',{sprintf('$t_{L,mean}$ = %.3f \n $\\sigma_{t_{L}}$ = %.4f',...
        tL_all(i), tL_std(i))},'LineStyle','none','Interpreter','latex',...
        'FontSize',.7*ax_sz,'FitBoxToText','on');
end
xlabel(sp(3),'Time Lag (days)','FontSize', lbl_sz);
% ------------------------------------
% printing and saving the figure
fig_results.PaperPositionMode = 'auto';
print('sigma_R_tl','-depsc','-r0');
movefile('sigma_R_tl.eps',path);
%--------------------------------------------------------------------------

%% ---------------- Figure 10 - Display error propagation results -----------
fig_results2 = figure(10);
set(fig_results2, 'Position', [100 100 1400 350]);
data_plot = [diff_amp_stat, diff_phase_stat, diff_joint_stat];
name_plot = {'Inverted from $R$','Inverted from $t_{L}$','Joint inversion'};
distr_plot = [Damp_stats, Dphase_stats, Djoint_stats];
text = {'amp','t_{L}','joint'};

for i = 1:3
    sp(i) = subplot(1,3,i);
    h = histfit(data_plot(:,i),25);
    h(1).FaceColor = [0.84 0.84 0.84];
    h(2).Color = 'k';
    xlim([0 4e5]); ylim([0 .2*numberSamples]);
    set(gca,'XMinorTick','on')
    title(name_plot(i),'FontSize', lbl_sz);
    
    annotation(fig_results2,'textbox','Position',sp(i).Position.*[1 1 1 1.8],...
        'HorizontalALignment','right',...
        'String',{sprintf('$D_{%s (mean)}$ = %.2s \n $\\sigma_{D_{%s}}$ = %.2s',...
        text{i}, distr_plot(i).mu, text{i}, distr_plot(i).sigma)},...
        'LineStyle','none','Interpreter','latex','FontSize',.8*ax_sz,...
        'FitBoxToText','on','VerticalALignment','middle');
    
    if i==2
        xlabel('Diffusivity ($m^2/day$)','FontSize', lbl_sz);
    end
end
% ------------------------------------
% printing and saving the figure
fig_results2.PaperPositionMode = 'auto';
print('sigma_D','-depsc','-r0');
movefile('sigma_D.eps',path);